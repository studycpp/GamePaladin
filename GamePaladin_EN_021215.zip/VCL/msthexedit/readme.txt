THexEditor component  Version 1.16 for Delphi 3/4
THexToCanvas component Version 1.0 beta 3 for Delphi 3/4

feb 02 1999

What's this ?
 A Delphi-component called THexEditor.

   it's useful to view and edit binary files,
   it can handle different byte-per-line values and multiple undo.
   v1.1 + find functionality , customizable layout
   v1.12 + half byte support , different code types ( ascii ,ansi ,dos ,mac ,ebcdic )
   v1.13 + AsText, AsHex property, MaskWhiteSpaces, better support for french kbd layout
   V1.14/1.15 fixed bugs with caret on nt and dynamic creation, added octal (base 8) support
              and OVERWRITE/INSERT mode
   V1.16 fixed : added WMGetDlgCode to avoid problems with shortcut-controls on the form
                 fixed updating when the font gets changed
                 added OnKeyPress-support ( now you can modify the key before THexEditor will parse it in this event )
         CHANGED : property name ReadOnly to ReadOnlyFile ( to avoid confusion, sorry )

         added : properties WantTabs and ReadOnlyView

 A Delphi-component called THexToCanvas.

   assign a THexEditor to it, and you can draw
   hex data to a canvas ( e.g. print preview, printing ) in various layouts



(C) 1998-1999, by Markus Stephany. All rights reserved.
************************************************************************************************
thexeditor and thextocanvas
are freeware and can be used in freeware, shareware and commercial productions without
my permission. you may modify the code, but please do not forget the documentation (and the
credits).

you must not sell the component or the source (except you made significant modifications).
************************************************************************************************

If there are any questions, comments or suggestions, or if you find any bugs, please send a
mail in English or German to :

MirBir.St@T-Online.de

And you can visit my homepage at :
http://home.t-online.de/home/MirBir.St/

==========
Disclaimer
==========
this software is provided "as is" without warranty of any kind,
either expressed or implied.  the entire risk as to the
quality and performance of the software is with you.  should the
software prove defective, you assume the cost of all necessary
servicing, repair, or correction.  in no event shall the author,
copyright holder, or any other party who may redistribute the
software be liable to you for damages, including any general,
special, incidental, or consequential damages arising out of
the use or inability to use the software (including, but not limited
to, loss of data, data being rendered inaccurate, loss of business
profits, loss of business information, business interruptions, loss
sustained by you or third parties, or a failure of the
software to operate with any other software) even if the author,
copyright holder, or other party has been advised of the
possibility of such damages.

to the point : you cannot make me responsable for anything that goes wrong with this...

======
Usage
======

THexEditor descends from TCustomGrid.
THexToCanvas descends from TComponent.

documentation can be found in doc.zip/THexEditor.txt and doc.zip/THexToCanvas.txt
a sample application that shows basic usage of these 2 component is included
in sample.zip

========
History
========

THexEditor:
 V 1.0 Beta 1 : first public release 08/15/98
 V 1.1 : 10/04/98
         added find,seek, customizable layout (many thanks to John Hamm, John@TEMPUS.COM )
 V 1.12: 10/25/98
	 added Half Byte (Nibble) support (insert/delete, swap hi/lo nibbles in hex view)
	 better performance
         the markers are now available for reading/writing
	 added support for some different code types in the char view :
         ANSI , 8 Bit ASCII ( OEM / Dos style ) , 7 Bit ASCII , Macintosh(TM) character set , IBM(TM) EBCDIC cp 038
	 also conversion of the file's contents (or a range of them) from one to another code type is possible
	 (many thanks to Christophe LE CORFEC, CLC@khalif.com for ebcdic and half byte suggestions)
 V 1.13: 11/07/98
         added AsText and AsHex property ( and converting functions for "aa00bb" style hex
         files ) , MaskWhiteSpaces property to avoid the '.' if you have a font that can
         display chars from #0 to #31; also typing capitals rather than lowercase chars in
         the char field is now possible ( most of this stuff has been suggested from
         Philippe Chessa , Philippe_Chessa@compuserve.com, thanks )
 V 1.14: not released
         fixed some bugs
         added currently unsupported variable line lengths
         added NoSizeChange property
 V 1.15  01/03/99
         added option odOctal to TOffsetDisplayStyle to display line offset in octal system ("8"-based)
         fixed a problem on creating a THexEditor dynamically ( thanks to John Shailes , JohnShailes@email.msn.com )
         property AllowInsertMode : Boolean ; if this is set to true, THexEditor doesn't overwrite
         but insert values at the current cursor position ( this cannot be set if NoSizeChange is True )
         property IsInsertMode : Boolean ; readonly, if it returns true, the current mode is
         inserting (see above )
         property AutoCaretMode : Boolean ; if true, the caret will be set to a block
         in overwrite mode and to a left line in insert mode automatically
 V 1.16  02/02/99
         added WMGetDlgCode to avoid problems with shortcut-controls on the form
         changed the property name ReadOnly to ReadOnlyFile ( to avoid confusion, sorry )
         fixed updating when the font gets changed
         added OnKeyPress-support ( now you can modify the key before THexEditor will parse it in this event )
         property WantTabs : Boolean ; if true, than you can navigate between char and hex field with the TAB key,
         if not, you can navigate between your form's controls with the TAB key, to change the current field in
         THexEditor, you have to use CTRL+T.
         property ReadOnlyView : Boolean ; if true, than the text/data in THexEditor can't edited via key presses,
         just selection , moving and scrolling are still available


THexToCanvas:
 V1.0 Beta   : first public release 10/05/98
 V1.0 Beta 2 : 10/25/98
	       added SwapNibbles support
 V1.0 Beta 3 : 01/03/99
               added support for octal system

Viel Spa� beim Programmieren w�nscht

Markus.

